package javaprogram;

public class EmplictTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a= 10.34;
		int b = (int)a;
		System.out.println(b);

	}

}


package javaprogram;

public class ImplictTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=10;
		double b;
		b=a;
		System.out.println(b);

	}


	}


package inheritance;

public class Access2 {
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Access1 obj = new Access1();
			
			System.out.println(obj.hours);
			System.out.println(obj.mins);
			System.out.println(obj.name);
			System.out.println(obj.tool);
			System.out.println(obj.x);
			System.out.println(obj.z);



	}

}

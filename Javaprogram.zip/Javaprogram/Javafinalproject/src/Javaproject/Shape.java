package Javaproject;

public class Shape {

	public void displayArea() {
        System.out.println("This shape does not have a specific area calculation method.");
    }

}